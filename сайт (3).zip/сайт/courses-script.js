// ДАННЫЕ КУРСОВ с путями к фото
const coursesData = [
  { id: 1, name: 'Стандартный курс', price: 12000, image: 'images/standard-course.jpg', desc: 'Полный курс вождения для новичков. Идеальный выбор для тех, кто никогда не сидел за рулем.', hours: 40, popular: true },
  { id: 2, name: 'Экспресс-курс', price: 18000, image: 'images/express-course.jpg', desc: 'Интенсивное обучение за 3-4 недели. Для тех, кто хочет получить права быстро.', hours: 60, popular: true },
  { id: 3, name: 'Курс обновления', price: 6500, image: 'images/refresh-course.jpg', desc: 'Освежить навыки опытным водителям. Идеально если давно не садились за руль.', hours: 16, popular: false },
  { id: 4, name: 'Горное вождение', price: 9000, image: 'images/mountain-course.jpg', desc: 'Специальная подготовка к горным дорогам. Серпантины, подъемы, спуски.', hours: 20, popular: true },
  { id: 5, name: 'Парковка и манёвры', price: 4000, image: 'images/parking-course.jpg', desc: 'Отточить навыки парковки и маневрирования в городских условиях.', hours: 8, popular: false },
  { id: 6, name: 'Онлайн теория', price: 2500, image: 'images/online-course.jpg', desc: 'Теоретическая подготовка ПДД онлайн. Учись где угодно, когда угодно.', hours: 12, popular: false }
];

let currentSort = 'default';
let searchTerm = '';
let currentCourse = null;

// Рендер курсов с фото вместо иконок
function renderCourses() {
  let filtered = coursesData.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.desc.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  if (currentSort === 'price-asc') filtered.sort((a, b) => a.price - b.price);
  else if (currentSort === 'price-desc') filtered.sort((a, b) => b.price - a.price);
  else if (currentSort === 'popular') filtered.sort((a, b) => b.popular - a.popular);
  
  const container = document.getElementById('coursesContainer');
  if (!container) return;
  
  if (filtered.length === 0) {
    container.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:60px;color:var(--muted);">Курсы не найдены. Попробуйте изменить поиск.</div>';
    return;
  }
  
  container.innerHTML = filtered.map(course => `
    <div class="course-card reveal">
      <div class="card-header">
        <div class="card-image">
          <img src="${course.image}" alt="${course.name}" loading="lazy" onerror="this.style.display='none'">
        </div>
        <div class="card-info">
          <h3 class="card-title">${course.name}</h3>
          ${course.popular ? '<div class="card-badge">ПОПУЛЯРНЫЙ</div>' : ''}
        </div>
      </div>
      <div class="card-body">
        <p class="card-desc">${course.desc}</p>
        <div class="card-meta">
          <div class="meta-item">⏱️ ${course.hours} часов</div>
          <div class="meta-item">🎓 Теория+Практика</div>
        </div>
        <div class="card-price">${course.price.toLocaleString('ru-RU')} <small>сом</small></div>
        <button class="btn-enroll" onclick="openCourseModal(${course.id})">📝 Записаться →</button>
      </div>
    </div>
  `).join('');
  
  // Анимация reveal
  document.querySelectorAll('.course-card').forEach((el, i) => {
    setTimeout(() => el.classList.add('visible'), i * 50);
  });
}

// Открыть модальное окно
function openCourseModal(courseId) {
  currentCourse = coursesData.find(c => c.id === courseId);
  if (!currentCourse) return;
  
  document.getElementById('modalTitle').textContent = currentCourse.name;
  document.getElementById('modalDesc').textContent = currentCourse.desc;
  document.getElementById('modalHours').textContent = currentCourse.hours;
  document.getElementById('modalPrice').innerHTML = `${currentCourse.price.toLocaleString('ru-RU')} <small>сом</small>`;
  document.getElementById('modalIcon').innerHTML = `<img src="${currentCourse.image}" alt="${currentCourse.name}" style="width:100%;height:120px;object-fit:cover;border-radius:12px;">`;
  
  document.getElementById('courseModal').style.display = 'flex';
}

function closeCourseModal() {
  document.getElementById('courseModal').style.display = 'none';
}

// Поиск
document.getElementById('searchInput')?.addEventListener('input', (e) => {
  searchTerm = e.target.value;
  renderCourses();
});

// Сортировка
document.getElementById('sortSelect')?.addEventListener('change', (e) => {
  currentSort = e.target.value;
  renderCourses();
});

// Отправка формы
document.getElementById('enrollForm')?.addEventListener('submit', (e) => {
  e.preventDefault();
  const name = document.getElementById('enrollName').value;
  const phone = document.getElementById('enrollPhone').value;
  const city = document.getElementById('enrollCity').value;
  const time = document.getElementById('enrollTime').value;
  
  const result = submitApplication({
    courseName: currentCourse.name,
    coursePrice: currentCourse.price,
    name, phone, city, time
  });
  
  if (result.success) {
    document.getElementById('modalMessage').innerHTML = `<div class="auth-success">✓ ${result.message}</div>`;
    setTimeout(() => {
      closeCourseModal();
      document.getElementById('enrollForm').reset();
      document.getElementById('modalMessage').innerHTML = '';
    }, 2000);
  }
});

// При клике на фон модального окна
document.getElementById('courseModal')?.addEventListener('click', (e) => {
  if (e.target.id === 'courseModal') closeCourseModal();
});

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', renderCourses);

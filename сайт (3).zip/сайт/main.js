// === СИСТЕМА АУТЕНТИФИКАЦИИ ===

function initAuth() {
  if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify({
      admin: {
        id: 'admin',
        email: 'admin@911.kg',
        password: 'admin123',
        name: 'Администратор',
        role: 'admin',
        createdAt: new Date().toISOString()
      }
    }));
  }
  if (!localStorage.getItem('applications')) {
    localStorage.setItem('applications', JSON.stringify([]));
  }
}

function register(email, password, name) {
  const users = JSON.parse(localStorage.getItem('users') || '{}');
  
  if (users[email]) {
    return { success: false, message: 'Этот email уже зарегистрирован' };
  }
  
  users[email] = {
    id: Date.now().toString(),
    email,
    password,
    name,
    role: 'user',
    createdAt: new Date().toISOString()
  };
  
  localStorage.setItem('users', JSON.stringify(users));
  return { success: true, message: 'Регистрация успешна! Вы можете войти.' };
}

function login(email, password) {
  const users = JSON.parse(localStorage.getItem('users') || '{}');
  const user = users[email];
  
  if (!user || user.password !== password) {
    return { success: false, message: 'Неверный email или пароль' };
  }
  
  localStorage.setItem('currentUser', JSON.stringify(user));
  return { success: true, user };
}

function logout() {
  localStorage.removeItem('currentUser');
}

function getCurrentUser() {
  const user = localStorage.getItem('currentUser');
  return user ? JSON.parse(user) : null;
}

function isAdmin() {
  const user = getCurrentUser();
  return user && user.role === 'admin';
}

function isLoggedIn() {
  return getCurrentUser() !== null;
}

// === УПРАВЛЕНИЕ ЗАЯВКАМИ ===

function submitApplication(formData) {
  const apps = JSON.parse(localStorage.getItem('applications') || '[]');
  const user = getCurrentUser();
  
  const app = {
    id: Date.now().toString(),
    ...formData,
    userId: user?.email || 'guest',
    userName: user?.name || formData.name,
    status: 'new',
    submittedAt: new Date().toISOString()
  };
  
  apps.push(app);
  localStorage.setItem('applications', JSON.stringify(apps));
  return { success: true, message: 'Заявка отправлена!', app };
}

function getApplications() {
  return JSON.parse(localStorage.getItem('applications') || '[]');
}

function updateApplicationStatus(appId, status) {
  const apps = JSON.parse(localStorage.getItem('applications') || '[]');
  const app = apps.find(a => a.id === appId);
  
  if (app) {
    app.status = status;
    app.updatedAt = new Date().toISOString();
    localStorage.setItem('applications', JSON.stringify(apps));
    return { success: true, app };
  }
  
  return { success: false, message: 'Заявка не найдена' };
}

function deleteApplication(appId) {
  const apps = JSON.parse(localStorage.getItem('applications') || '[]');
  const filtered = apps.filter(a => a.id !== appId);
  localStorage.setItem('applications', JSON.stringify(filtered));
  return { success: true };
}

// === УПРАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯМИ ===

function getAllUsers() {
  return Object.values(JSON.parse(localStorage.getItem('users') || '{}'));
}

function deleteUser(email) {
  const users = JSON.parse(localStorage.getItem('users') || '{}');
  if (email === 'admin@911.kg') {
    return { success: false, message: 'Нельзя удалить админа' };
  }
  delete users[email];
  localStorage.setItem('users', JSON.stringify(users));
  return { success: true };
}

function updateUserRole(email, role) {
  const users = JSON.parse(localStorage.getItem('users') || '{}');
  if (users[email]) {
    users[email].role = role;
    localStorage.setItem('users', JSON.stringify(users));
    return { success: true };
  }
  return { success: false };
}

// Initialize Auth
if (typeof initAuth === 'function') initAuth();

// Scroll reveal
const obs = new IntersectionObserver(entries => {
  entries.forEach((e, i) => {
    if (e.isIntersecting) {
      setTimeout(() => e.target.classList.add('visible'), i * 70);
      obs.unobserve(e.target);
    }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => obs.observe(el));

// Nav shadow
window.addEventListener('scroll', () => {
  const navbar = document.getElementById('navbar');
  if (navbar) navbar.style.boxShadow = window.scrollY > 20 ? '0 4px 24px rgba(27,67,50,0.1)' : '';
});

// Mobile nav
const hamBtn = document.getElementById('ham');
if (hamBtn) {
  hamBtn.addEventListener('click', () => {
    const ul = document.getElementById('nav-ul');
    const open = ul.style.display === 'flex';
    Object.assign(ul.style, {
      display: open ? 'none' : 'flex',
      flexDirection: 'column',
      position: 'fixed',
      top: '68px',
      left: '0',
      right: '0',
      background: '#fff',
      padding: '22px 5%',
      gap: '16px',
      borderBottom: '2px solid #1B4332',
      boxShadow: '0 8px 28px rgba(27,67,50,0.1)',
      zIndex: '999'
    });
  });
}

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const id = a.getAttribute('href');
    if (id === '#') return;
    e.preventDefault();
    document.querySelector(id)?.scrollIntoView({ behavior: 'smooth' });
    const navUl = document.getElementById('nav-ul');
    if (navUl) navUl.style.display = '';
  });
});

// Form
function handleSubmit(btn) {
  btn.textContent = '✓ Заявка отправлена!';
  btn.style.background = 'var(--green-light)';
  btn.disabled = true;
  setTimeout(() => {
    btn.textContent = 'Отправить заявку →';
    btn.style.background = '';
    btn.disabled = false;
  }, 3000);
}

// =============================================
// Auth Modal — все элементы с null-проверками
// =============================================

let authMode = 'login';

const authOverlay  = document.getElementById('auth-overlay');
const authTrigger  = document.getElementById('auth-trigger');
const authClose    = document.getElementById('auth-close');
const authSwitchBtn = document.getElementById('auth-switch-btn');
const authForm     = document.getElementById('auth-form');
const authMessage  = document.getElementById('auth-message');
const authTitle    = document.getElementById('auth-title');
const authSubtitle = document.getElementById('auth-subtitle');
const authBtn      = document.getElementById('auth-btn');
const authEmail    = document.getElementById('auth-email');
const authPassword = document.getElementById('auth-password');

// Глобальная функция — работает на любой странице через onclick="openAuthModal()"
function openAuthModal() {
  if (authOverlay) {
    authOverlay.classList.add('active');
    authMode = 'login';
    updateAuthUI();
  }
}
window.openAuthModal = openAuthModal;

if (authTrigger) {
  authTrigger.addEventListener('click', (e) => {
    e.preventDefault();
    openAuthModal();
  });
}

if (authClose) {
  authClose.addEventListener('click', () => {
    authOverlay.classList.remove('active');
    if (authMessage) authMessage.innerHTML = '';
  });
}

if (authOverlay) {
  authOverlay.addEventListener('click', (e) => {
    if (e.target === authOverlay) authOverlay.classList.remove('active');
  });
}

if (authSwitchBtn) {
  authSwitchBtn.addEventListener('click', (e) => {
    e.preventDefault();
    authMode = authMode === 'login' ? 'register' : 'login';
    updateAuthUI();
  });
}

function updateAuthUI() {
  if (!authTitle || !authSubtitle || !authBtn || !authSwitchBtn || !authForm) return;

  if (authMode === 'login') {
    authTitle.textContent = 'Вход';
    authSubtitle.textContent = 'Войдите в свой аккаунт';
    authBtn.textContent = 'Войти';
    authSwitchBtn.textContent = 'Зарегистрироваться';
    authForm.querySelector('[placeholder="Имя"]')?.remove();
  } else {
    authTitle.textContent = 'Регистрация';
    authSubtitle.textContent = 'Создайте новый аккаунт';
    authBtn.textContent = 'Зарегистрироваться';
    authSwitchBtn.textContent = 'Уже есть аккаунт?';
    if (!authForm.querySelector('[placeholder="Имя"]')) {
      const nameInput = document.createElement('input');
      nameInput.type = 'text';
      nameInput.className = 'auth-input';
      nameInput.placeholder = 'Имя';
      nameInput.required = true;
      authForm.insertBefore(nameInput, authForm.querySelector('[type="password"]'));
    }
  }
  if (authMessage) authMessage.innerHTML = '';
}

function handleAuthSubmit(e) {
  e.preventDefault();
  if (!authEmail || !authPassword) return;

  const email    = authEmail.value.trim();
  const password = authPassword.value;
  const name     = authForm?.querySelector('[placeholder="Имя"]')?.value.trim() || '';

  if (!email || !password) {
    showMessage('Заполните все поля', 'error');
    return;
  }

  try {
    let result;
    if (authMode === 'login') {
      result = login(email, password);
    } else {
      if (!name) {
        showMessage('Введите ваше имя', 'error');
        return;
      }
      result = register(email, password, name);
    }

    if (result.success) {
      showMessage(authMode === 'login' ? '✓ Добро пожаловать!' : '✓ Регистрация успешна!', 'success');
      setTimeout(() => {
        if (authMode === 'login') {
          if (authOverlay) authOverlay.classList.remove('active');
          if (authTrigger) authTrigger.textContent = '🧑 ' + result.user.name;
        } else {
          authMode = 'login';
          updateAuthUI();
          if (authEmail) authEmail.value = email;
          if (authPassword) authPassword.value = '';
        }
      }, 1500);
    } else {
      showMessage(result.message, 'error');
    }
  } catch (err) {
    showMessage('Ошибка: ' + err.message, 'error');
  }
}
window.handleAuthSubmit = handleAuthSubmit;

function showMessage(msg, type) {
  if (!authMessage) return;
  authMessage.innerHTML = `<div class="auth-${type}">${msg}</div>`;
  setTimeout(() => {
    if (authMessage.innerHTML.includes(msg)) authMessage.innerHTML = '';
  }, 3000);
}

// Branch panel animation (только если элемент существует)
const branchPanel = document.getElementById('branch-panel');
if (branchPanel && typeof window.showPanel === 'function') {
  const originalShowPanel = window.showPanel;
  window.showPanel = function (key) {
    branchPanel.classList.remove('show');
    setTimeout(() => {
      originalShowPanel(key);
      branchPanel.classList.add('show');
    }, 150);
  };
}

// PAGE TRANSITION
document.addEventListener('DOMContentLoaded', () => {
  document.body.classList.add('page-enter');
  handleScrollAnimations();
});

// SMOOTH SCROLL REVEAL
function handleScrollAnimations() {
  const reveals = document.querySelectorAll('.reveal, .card-enhance, .review-card, .course-card');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, idx) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('visible'), idx * 100);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  reveals.forEach(el => observer.observe(el));
}

// NAVBAR SCROLL EFFECT
window.addEventListener('scroll', () => {
  const navbar = document.getElementById('navbar');
  if (!navbar) return;
  if (window.scrollY > 20) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

// PAGE LINK TRANSITIONS
document.querySelectorAll('a:not([href^="#"]):not([target="_blank"])').forEach(link => {
  link.addEventListener('click', (e) => {
    const href = link.getAttribute('href');
    if (href && !href.includes('#')) {
      e.preventDefault();
      document.body.style.opacity = '0';
      document.body.style.transform = 'translateY(20px)';
      setTimeout(() => { window.location.href = href; }, 300);
    }
  });
});

// BUTTON RIPPLE EFFECT
document.querySelectorAll('button, .btn-primary, .btn-outline').forEach(btn => {
  btn.addEventListener('click', function (e) {
    const ripple = document.createElement('span');
    const rect = this.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.classList.add('ripple');
    this.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
  });
});

// SMOOTH COUNTER ANIMATIONS
function animateCounter(element, target, duration = 2000) {
  if (element.getAttribute('data-animated')) return;
  const increment = target / (duration / 16);
  let current = 0;
  const counter = setInterval(() => {
    current += increment;
    if (current >= target) {
      element.textContent = target;
      clearInterval(counter);
      element.setAttribute('data-animated', 'true');
    } else {
      element.textContent = Math.floor(current);
    }
  }, 16);
}

// OBSERVE COUNTERS
const counterObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting && entry.target.classList.contains('counter')) {
      const target = parseInt(entry.target.getAttribute('data-target')) || parseInt(entry.target.textContent);
      animateCounter(entry.target, target);
      counterObserver.unobserve(entry.target);
    }
  });
});
document.querySelectorAll('.counter').forEach(el => counterObserver.observe(el));

// REVEAL INITIALIZATION
const obs2 = new IntersectionObserver(entries => {
  entries.forEach((e, i) => {
    if (e.isIntersecting) {
      setTimeout(() => e.target.classList.add('visible'), i * 70);
      obs2.unobserve(e.target);
    }
  });
}, { threshold: 0.1 });
document.querySelectorAll('.reveal').forEach(el => obs2.observe(el));

// NAV LINK ACTIVE STATE
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.nav-links a').forEach(link => {
    if (link.getAttribute('href') === window.location.pathname) {
      link.classList.add('active');
    }
  });
});

// MOBILE NAV ANIMATION
const ham = document.getElementById('ham');
if (ham) {
  ham.addEventListener('click', () => {
    ham.classList.toggle('active');
    const ul = document.getElementById('nav-ul');
    if (!ul) return;
    if (ul.style.display === 'flex') {
      ul.style.animation = 'slideOutUp .3s ease forwards';
      setTimeout(() => { ul.style.display = 'none'; }, 300);
    } else {
      ul.style.display = 'flex';
      ul.style.animation = 'slideInDown .3s ease forwards';
    }
  });
}

// SCROLL TO TOP BUTTON
window.addEventListener('scroll', () => {
  const scrollTop = document.querySelector('.scroll-to-top');
  if (!scrollTop) return;
  scrollTop.classList.toggle('show', window.scrollY > 300);
});

// LAZY LOAD IMAGES
if ('IntersectionObserver' in window) {
  const imageObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.getAttribute('data-src');
        img.classList.add('loaded');
        imageObserver.unobserve(img);
      }
    });
  });
  document.querySelectorAll('img[data-src]').forEach(img => imageObserver.observe(img));
}

// FORM FIELD ANIMATIONS
document.querySelectorAll('input, textarea, select').forEach(field => {
  field.addEventListener('focus', function () {
    this.style.boxShadow = '0 0 0 4px rgba(45, 106, 79, 0.1)';
    this.style.borderColor = '#40916C';
  });
  field.addEventListener('blur', function () {
    this.style.boxShadow = '';
    this.style.borderColor = '';
  });
});

// TYPING ANIMATION
function typeText(element, text, speed = 50) {
  element.textContent = '';
  let i = 0;
  const type = () => {
    if (i < text.length) {
      element.textContent += text.charAt(i);
      i++;
      setTimeout(type, speed);
    }
  };
  type();
}

// PARALLAX EFFECT
window.addEventListener('scroll', () => {
  document.querySelectorAll('[data-parallax]').forEach(el => {
    const speed = el.getAttribute('data-parallax');
    el.style.transform = `translateY(${window.scrollY * speed}px)`;
  });
});

// PRESERVE SCROLL ON PAGE RELOAD
window.addEventListener('beforeunload', () => {
  sessionStorage.setItem('scrollPosition', window.scrollY);
});
window.addEventListener('load', () => {
  const scrollPos = sessionStorage.getItem('scrollPosition');
  if (scrollPos) {
    window.scrollTo(0, parseInt(scrollPos));
    sessionStorage.removeItem('scrollPosition');
  }
});

// RESPONSIVE ANIMATIONS
const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
if (mediaQuery.matches) {
  document.documentElement.style.scrollBehavior = 'auto';
}

// EXPORT FUNCTIONS
window.typeText = typeText;
window.animateCounter = animateCounter;
window.handleScrollAnimations = handleScrollAnimations;

/* SMOOTH ANIMATIONS & PAGE TRANSITIONS */

// PAGE ENTRY WITH FADE-IN EFFECT
document.addEventListener('DOMContentLoaded', () => {
  document.body.style.opacity = '1';
  document.body.style.transform = 'translateY(0)';
  document.body.classList.add('page-enter');
  
  handleScrollAnimations();
  initPageTransitions();
});

// SCROLL REVEAL ANIMATIONS
function handleScrollAnimations() {
  const reveals = document.querySelectorAll('.reveal, .card-enhance, .review-card, .course-card, .rc, .cc');
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, idx) => {
      if(entry.isIntersecting) {
        setTimeout(() => {
          entry.target.classList.add('visible');
        }, idx * 80);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.05 });
  
  reveals.forEach(el => observer.observe(el));
}

// NAVBAR SCROLL EFFECT
window.addEventListener('scroll', () => {
  const navbar = document.getElementById('navbar');
  if(window.scrollY > 20) {
    navbar.style.boxShadow = '0 4px 24px rgba(27,67,50,0.1)';
    navbar.style.background = 'rgba(255,255,255,0.98)';
    navbar.style.backdropFilter = 'blur(10px)';
  } else {
    navbar.style.boxShadow = 'none';
    navbar.style.background = '#fff';
    navbar.style.backdropFilter = 'none';
  }
});

// PAGE LINK SMOOTH TRANSITIONS
function initPageTransitions() {
  document.querySelectorAll('a:not([href^="#"]):not([target="_blank"]):not([onclick])').forEach(link => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if(href && !href.includes('#') && !href.includes('javascript')) {
        e.preventDefault();
        
        // Fade out animation
        document.body.style.transition = 'opacity 0.4s ease-out, transform 0.4s ease-out';
        document.body.style.opacity = '0';
        document.body.style.transform = 'translateY(15px)';
        
        // Navigate after delay
        setTimeout(() => {
          window.location.href = href;
        }, 400);
      }
    });
  });
}

// BUTTON RIPPLE EFFECT
document.addEventListener('click', function(e) {
  if(e.target.tagName === 'BUTTON' || e.target.classList.contains('btn-primary') || e.target.classList.contains('btn-outline')) {
    const btn = e.target.closest('button') || e.target;
    const ripple = document.createElement('span');
    const rect = btn.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;
    
    ripple.style.position = 'absolute';
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.style.background = 'radial-gradient(circle, rgba(255,255,255,0.6), transparent)';
    ripple.style.borderRadius = '50%';
    ripple.style.pointerEvents = 'none';
    ripple.style.animation = 'ripple 0.6s ease-out forwards';
    
    if(btn.style.position !== 'absolute' && btn.style.position !== 'relative' && btn.style.position !== 'fixed') {
      btn.style.position = 'relative';
      btn.style.overflow = 'hidden';
    }
    
    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
  }
});

// PARALLAX SCROLL EFFECT
window.addEventListener('scroll', () => {
  const parallaxElements = document.querySelectorAll('[data-parallax]');
  parallaxElements.forEach(el => {
    const scrollY = window.scrollY;
    const elementOffset = el.offsetTop;
    const distance = scrollY - elementOffset;
    el.style.transform = `translateY(${distance * 0.5}px)`;
  });
});

// LAZY LOAD IMAGES
function lazyLoadImages() {
  const images = document.querySelectorAll('img[data-src]');
  const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if(entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src;
        img.removeAttribute('data-src');
        observer.unobserve(img);
      }
    });
  });
  
  images.forEach(img => imageObserver.observe(img));
}

// FORM FIELD FOCUS ANIMATIONS
document.addEventListener('focusin', (e) => {
  if(e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
    e.target.style.transition = 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)';
    e.target.style.boxShadow = '0 0 0 4px rgba(45,106,79,0.2)';
  }
});

document.addEventListener('focusout', (e) => {
  if(e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
    e.target.style.boxShadow = 'none';
  }
});

// COUNTER ANIMATION FOR NUMBERS
function animateCounter(element, target, duration = 2000) {
  if(element.getAttribute('data-animated')) return;
  
  const start = 0;
  const increment = target / (duration / 16);
  let current = 0;
  
  const counter = setInterval(() => {
    current += increment;
    if(current >= target) {
      element.textContent = target;
      clearInterval(counter);
      element.setAttribute('data-animated', 'true');
    } else {
      element.textContent = Math.floor(current);
    }
  }, 16);
}

// TYPING ANIMATION
function typeText(element, text, speed = 50) {
  element.textContent = '';
  let index = 0;
  const interval = setInterval(() => {
    if(index < text.length) {
      element.textContent += text[index];
      index++;
    } else {
      clearInterval(interval);
    }
  }, speed);
}

// HOVER LIFT EFFECT
document.addEventListener('mouseover', (e) => {
  if(e.target.classList.contains('card-enhance') || e.target.classList.contains('rc') || e.target.classList.contains('cc')) {
    e.target.style.transform = 'translateY(-8px) scale(1.02)';
  }
});

document.addEventListener('mouseout', (e) => {
  if(e.target.classList.contains('card-enhance') || e.target.classList.contains('rc') || e.target.classList.contains('cc')) {
    e.target.style.transform = 'translateY(0) scale(1)';
  }
});

// HAMBURGER MENU TOGGLE
const hamburger = document.getElementById('ham');
const navUl = document.getElementById('nav-ul');

if(hamburger) {
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    navUl.classList.toggle('active');
  });
}

// CLOSE MOBILE MENU ON LINK CLICK
document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => {
    hamburger?.classList.remove('active');
    navUl?.classList.remove('active');
  });
});

// SMOOTH COLOR CHANGE ON SCROLL
window.addEventListener('scroll', () => {
  const scrollPercentage = (window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100;
  
  // Update any progress indicators
  const progressBars = document.querySelectorAll('[data-progress]');
  progressBars.forEach(bar => {
    bar.style.width = scrollPercentage + '%';
  });
});

// INITIALIZE ON PAGE LOAD
document.addEventListener('DOMContentLoaded', () => {
  lazyLoadImages();
  initPageTransitions();
  
  // Animate counters when visible
  const counterElements = document.querySelectorAll('[data-counter]');
  const counterObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting && !entry.target.getAttribute('data-animated')) {
        const target = parseInt(entry.target.getAttribute('data-counter'));
        animateCounter(entry.target, target);
        counterObserver.unobserve(entry.target);
      }
    });
  });
  
  counterElements.forEach(el => counterObserver.observe(el));
});

// ADD RIPPLE ANIMATION KEYFRAMES
const style = document.createElement('style');
style.textContent = `
  @keyframes ripple {
    to {
      transform: scale(4);
      opacity: 0;
    }
  }
  
  body {
    opacity: 1;
    transform: translateY(0);
    transition: opacity 0.4s ease-out, transform 0.4s ease-out;
  }
`;
document.head.appendChild(style);
